// supabase/functions/connect-process-events/index.ts
var import_supabase_js_2_49 = require("https://esm.sh/@supabase/supabase-js@2.49.1");
var import_server = require("https://deno.land/std@0.168.0/http/server.ts");
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function jsonRes(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" }
  });
}
(0, import_server.serve)(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }
  try {
    if (req.method !== "POST") {
      return jsonRes({ error: "method_not_allowed" }, 405);
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const svc = (0, import_supabase_js_2_49.createClient)(supabaseUrl, serviceKey);
    const { webhook_event_id, limit = 10 } = await req.json();
    let eventsToProcess = [];
    if (webhook_event_id) {
      const { data: event, error: fetchErr } = await svc.from("webhook_events").select("*").eq("id", webhook_event_id).single();
      if (fetchErr || !event) {
        return jsonRes({ error: "event_not_found" }, 404);
      }
      eventsToProcess = [event];
    } else {
      const { data: events, error: fetchErr } = await svc.from("webhook_events").select("*").in("status", ["received", "failed"]).order("received_at", { ascending: true }).limit(limit);
      if (fetchErr) {
        console.error("fetch events error:", fetchErr);
        return jsonRes({ error: "fetch_failed" }, 500);
      }
      eventsToProcess = events || [];
    }
    let processedCount = 0;
    let failedCount = 0;
    for (const event of eventsToProcess) {
      try {
        const eventId = event.id;
        const eventType = event.event_type;
        const payload = event.payload;
        const storeId = event.store_id;
        const connectionId = event.connection_id;
        await svc.from("webhook_events").update({ status: "processing", attempts: (event.attempts || 0) + 1 }).eq("id", eventId);
        let transactionsToInsert = [];
        if (event.provider === "pluggy") {
          if (eventType.startsWith("payment")) {
            const tx = parsePluggyPaymentEvent(payload, storeId, connectionId);
            if (tx) {
              transactionsToInsert.push(tx);
            }
          }
        }
        if (transactionsToInsert.length > 0) {
          const externalAccountId = payload.accountId;
          const { data: account } = await svc.from("bank_accounts").select("id").eq("external_account_id", externalAccountId).eq("store_id", storeId).single();
          if (account) {
            const { error: rpcErr } = await svc.rpc("connect_save_bank_transactions", {
              p_store_id: storeId,
              p_account_id: account.id,
              p_transactions: transactionsToInsert
            });
            if (rpcErr) {
              throw new Error(`RPC error: ${rpcErr.message}`);
            }
            const { error: matchErr } = await svc.rpc("connect_run_matching", {
              p_store_id: storeId,
              p_account_id: account.id,
              p_trigger_source: "webhook"
            });
            if (matchErr) {
              console.error(`matching error: ${matchErr.message}`);
            }
          }
        }
        await svc.from("webhook_events").update({
          status: "processed",
          processed_at: (/* @__PURE__ */ new Date()).toISOString()
        }).eq("id", eventId);
        processedCount++;
      } catch (e) {
        failedCount++;
        const error = String(e);
        await svc.from("webhook_events").update({
          status: "failed",
          last_error: error.substring(0, 500),
          attempts: (event.attempts || 0) + 1
        }).eq("id", event.id);
        console.error(`event processing error (${event.id}):`, error);
      }
    }
    return jsonRes({
      processed: processedCount,
      failed: failedCount,
      total: eventsToProcess.length
    }, 200);
  } catch (e) {
    console.error("connect-process-events error:", e);
    return jsonRes({ error: "internal_error", details: String(e) }, 500);
  }
});
function parsePluggyPaymentEvent(payload, storeId, connectionId) {
  const id = payload.id;
  const amount = payload.amount;
  const fees = payload.fees || 0;
  const type = payload.type;
  const status = payload.status;
  const date = payload.date;
  const description = payload.description;
  if (!id || amount == null || !type) {
    return null;
  }
  const direction = type === "credit" ? "credit" : "debit";
  const txStatus = status === "completed" ? "confirmed" : "pending";
  let method = "other";
  const desc = (description || "").toLowerCase();
  if (desc.includes("pix")) method = "pix";
  else if (desc.includes("cart\xE3o") || desc.includes("card")) method = "card";
  else if (desc.includes("boleto")) method = "boleto";
  else if (desc.includes("transf")) method = "transfer";
  return {
    provider: "pluggy",
    external_tx_id: id,
    direction,
    method,
    gross_amount: Math.abs(amount),
    fee_amount: Math.abs(fees),
    net_amount: Math.abs(amount) - Math.abs(fees),
    currency: "BRL",
    payer_name: null,
    // Pluggy doesn't always provide this
    payer_doc_mask: null,
    description,
    occurred_at: new Date(date).toISOString(),
    settled_at: status === "completed" ? new Date(date).toISOString() : null,
    status: txStatus,
    metadata: {
      pluggy_payload: payload
    }
  };
}
