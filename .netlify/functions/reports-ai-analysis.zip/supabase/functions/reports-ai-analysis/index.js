// supabase/functions/reports-ai-analysis/index.ts
var import_supabase_js_2_49 = require("https://esm.sh/@supabase/supabase-js@2.49.1");
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type"
};
var LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
var SB_URL = Deno.env.get("SUPABASE_URL");
var SB_ANON = Deno.env.get("SUPABASE_ANON_KEY");
var SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" }
  });
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
    if (!LOVABLE_API_KEY) return json({ error: "missing_key", message: "LOVABLE_API_KEY n\xE3o configurada." }, 500);
    const auth = req.headers.get("Authorization");
    if (!auth?.startsWith("Bearer ")) return json({ error: "missing_token" }, 401);
    const userClient = (0, import_supabase_js_2_49.createClient)(SB_URL, SB_ANON, { global: { headers: { Authorization: auth } } });
    const { data: { user }, error: authErr } = await userClient.auth.getUser();
    if (authErr || !user) return json({ error: "missing_token" }, 401);
    const svc = (0, import_supabase_js_2_49.createClient)(SB_URL, SB_SERVICE);
    const { data: profile } = await svc.from("profiles").select("id, store_id, is_active").eq("auth_user_id", user.id).single();
    if (!profile?.is_active) return json({ error: "sem_permissao" }, 403);
    const body = await req.json().catch(() => ({}));
    const { summary, sales, returns, stock, finance, period } = body || {};
    if (!summary || !period) return json({ error: "payload_invalido" }, 400);
    const fmt = (v) => `R$ ${Number(v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    const topProd = (sales?.top_products || []).slice(0, 3).map((p) => `${p.name} (${p.qty}un, ${fmt(p.revenue)})`).join(", ") || "\u2014";
    const topMethods = Object.entries(sales?.payment_methods || {}).map(([m, v]) => `${m}: ${fmt(v.amount)}`).join(", ") || "\u2014";
    const topExpenses = Object.entries(finance?.expense_by_category || {}).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([c, v]) => `${c}: ${fmt(v)}`).join(", ") || "\u2014";
    const userPrompt = `Analise os dados de opera\xE7\xE3o de uma loja entre ${period.from} e ${period.to}.

DADOS:
- Faturamento bruto: ${fmt(summary.gross_revenue)}
- Faturamento l\xEDquido: ${fmt(summary.net_revenue)}
- Lucro bruto: ${fmt(summary.gross_profit)}
- Despesas totais: ${fmt(summary.expense_total)}
- Compras de estoque: ${fmt(summary.purchase_total)}
- Total de vendas: ${summary.sales_count}
- Ticket m\xE9dio: ${fmt(sales?.ticket_avg || 0)}
- Devolu\xE7\xF5es: ${summary.returns_count} (impacto ${fmt(summary.refund_total)})
- Saldo do per\xEDodo: ${fmt(summary.balance)}
- Vendas a receber (pendente): ${fmt(summary.amount_pending || 0)} em ${summary.pending_sales_count || 0} venda(s)
- Vendas vencidas: ${summary.overdue_sales_count || 0} (${fmt(summary.overdue_amount || 0)})
- Top produtos vendidos: ${topProd}
- Formas de pagamento: ${topMethods}
- Top despesas: ${topExpenses}
- Produtos com estoque cr\xEDtico: ${(stock?.low_stock || []).length}

Chame a fun\xE7\xE3o "report_analysis" com:
- summary: 2-4 frases curtas em pt-BR descrevendo o desempenho geral (faturamento, lucro, vendas)
- alerts: lista de 0-5 pontos de aten\xE7\xE3o concretos (ex.: "X produtos sem estoque", "Despesa Y maior que Z")
- suggestions: lista de 0-5 a\xE7\xF5es pr\xE1ticas e espec\xEDficas (ex.: "Reabaste\xE7a produto X", "Cobre clientes com vencimento atrasado")

Seja direto, evite generalidades. Se algo estiver bom, mencione no summary. Use valores e nomes reais dos dados.`;
    const tools = [
      {
        type: "function",
        function: {
          name: "report_analysis",
          description: "Retorna an\xE1lise estruturada do per\xEDodo com resumo, alertas e sugest\xF5es.",
          parameters: {
            type: "object",
            properties: {
              summary: {
                type: "string",
                description: "Resumo executivo curto (2 a 4 frases) do desempenho do per\xEDodo."
              },
              alerts: {
                type: "array",
                description: "Pontos de aten\xE7\xE3o/alertas (0 a 5 itens).",
                items: { type: "string" }
              },
              suggestions: {
                type: "array",
                description: "Sugest\xF5es pr\xE1ticas e acion\xE1veis (0 a 5 itens).",
                items: { type: "string" }
              }
            },
            required: ["summary", "alerts", "suggestions"],
            additionalProperties: false
          }
        }
      }
    ];
    const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: "Voc\xEA \xE9 um analista financeiro de varejo. Responda em pt-BR de forma clara, objetiva e baseada nos dados fornecidos." },
          { role: "user", content: userPrompt }
        ],
        tools,
        tool_choice: { type: "function", function: { name: "report_analysis" } }
      })
    });
    if (resp.status === 429) return json({ error: "rate_limit", message: "Muitas requisi\xE7\xF5es \xE0 IA. Aguarde um momento." }, 429);
    if (resp.status === 402) return json({ error: "no_credits", message: "Cr\xE9ditos de IA esgotados. Adicione cr\xE9ditos no workspace." }, 402);
    if (!resp.ok) {
      const t = await resp.text();
      console.error("AI gateway error", resp.status, t);
      return json({ error: "ai_error", message: "Erro ao gerar an\xE1lise." }, 500);
    }
    const data = await resp.json();
    const message = data?.choices?.[0]?.message;
    let parsed = {
      summary: "",
      alerts: [],
      suggestions: []
    };
    const toolCall = message?.tool_calls?.[0];
    if (toolCall?.function?.arguments) {
      try {
        const args = JSON.parse(toolCall.function.arguments);
        parsed = {
          summary: String(args.summary || ""),
          alerts: Array.isArray(args.alerts) ? args.alerts.map((s) => String(s)).filter(Boolean) : [],
          suggestions: Array.isArray(args.suggestions) ? args.suggestions.map((s) => String(s)).filter(Boolean) : []
        };
      } catch (e) {
        console.error("Failed to parse tool call args:", e);
      }
    }
    if (!parsed.summary && message?.content) {
      parsed.summary = String(message.content).slice(0, 800);
    }
    const textParts = [];
    if (parsed.summary) textParts.push(parsed.summary);
    if (parsed.alerts.length) textParts.push("\nPontos de aten\xE7\xE3o:\n" + parsed.alerts.map((a) => `\u2022 ${a}`).join("\n"));
    if (parsed.suggestions.length) textParts.push("\nSugest\xF5es:\n" + parsed.suggestions.map((s) => `\u2192 ${s}`).join("\n"));
    const text = textParts.join("\n") || "Sem an\xE1lise dispon\xEDvel.";
    const { data: saved, error: saveErr } = await svc.from("report_ai_analyses").insert({
      store_id: profile.store_id,
      created_by: profile.id,
      report_type: "detailed",
      period_start: period.from,
      period_end: period.to,
      analysis_text: text,
      metadata: {
        gross_revenue: summary.gross_revenue,
        net_revenue: summary.net_revenue,
        sales_count: summary.sales_count,
        structured: parsed
      }
    }).select("id, created_at").single();
    if (saveErr) console.error("Failed to persist analysis:", saveErr);
    return json({
      analysis: text,
      structured: parsed,
      id: saved?.id || null,
      created_at: saved?.created_at || (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (e) {
    console.error("reports-ai-analysis error:", e);
    return json({ error: "internal_error", message: "Erro interno." }, 500);
  }
});
