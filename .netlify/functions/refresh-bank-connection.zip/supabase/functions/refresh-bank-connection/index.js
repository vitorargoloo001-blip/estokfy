// supabase/functions/refresh-bank-connection/index.ts
var import_server = require("https://deno.land/std@0.208.0/http/server.ts");
var import_supabase_js_2 = require("https://esm.sh/@supabase/supabase-js@2");
var supabase = (0, import_supabase_js_2.createClient)(
  Deno.env.get("SUPABASE_URL") || "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || ""
);
var PLUGGY_CLIENT_ID = Deno.env.get("PLUGGY_CLIENT_ID");
var PLUGGY_CLIENT_SECRET = Deno.env.get("PLUGGY_CLIENT_SECRET");
var PLUGGY_API_BASE = "https://api.pluggy.ai";
(0, import_server.serve)(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
      }
    });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  }
  try {
    const payload = await req.json();
    const { store_id, bank_connection_id } = payload;
    if (!store_id || !bank_connection_id) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }
    const { data: bankConnData, error: bcError } = await supabase.rpc(
      "get_bank_connection_token",
      {
        p_bank_connection_id: bank_connection_id,
        p_store_id: store_id
      }
    );
    if (bcError || !bankConnData || bankConnData.length === 0) {
      return new Response(JSON.stringify({ error: "Bank connection not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json" }
      });
    }
    const { provider, provider_connection_id, needs_refresh } = bankConnData[0];
    if (!needs_refresh) {
      return new Response(
        JSON.stringify({
          success: true,
          message: "Token is still valid, no refresh needed",
          needs_refresh: false
        }),
        { status: 200, headers: { "Content-Type": "application/json" } }
      );
    }
    if (provider !== "pluggy") {
      return new Response(
        JSON.stringify({ error: "Unsupported provider for refresh" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }
    console.log(`Token refresh needed for connection ${provider_connection_id}`);
    const { error: updateError } = await supabase.from("bank_connections").update({
      sync_status: "pending",
      last_sync_error: "Token expired, re-authentication required"
    }).eq("id", bank_connection_id);
    if (updateError) {
      return new Response(
        JSON.stringify({ error: "Failed to update connection status" }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }
    return new Response(
      JSON.stringify({
        success: true,
        message: "Re-authentication required",
        needs_reauth: true,
        auth_url: `${PLUGGY_API_BASE}/auth/credential?client_id=${PLUGGY_CLIENT_ID}&response_type=code`
      }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in refresh-bank-connection:", error);
    return new Response(
      JSON.stringify({ error: String(error) }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
});
