// supabase/functions/ai-support-chat/index.ts
var import_supabase_js_2_49 = require("https://esm.sh/@supabase/supabase-js@2.49.1");
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version"
};
var SB_URL = Deno.env.get("SUPABASE_URL");
var SB_ANON = Deno.env.get("SUPABASE_ANON_KEY");
var SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
var LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
var AI_GATEWAY = "https://ai.gateway.lovable.dev/v1/chat/completions";
function json(data, status) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" }
  });
}
function redactSensitive(text) {
  return text.replace(/\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/g, "***CPF***").replace(/\b[A-Za-z0-9]{32,}\b/g, "***TOKEN***").replace(/\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/g, "***CARD***");
}
var SYSTEM_PROMPT = `Voc\xEA \xE9 o assistente de suporte IA do Estokfy (gest\xE3o de loja de pe\xE7as). Seu nome \xE9 "Suporte IA".

REGRAS CR\xCDTICAS:
- Nunca pe\xE7a senhas, chaves de API ou dados banc\xE1rios completos
- Mascare CPF, CNPJ e IDs de transa\xE7\xE3o nas respostas
- Antes de executar qualquer a\xE7\xE3o que modifique dados (venda, ajuste de estoque, devolu\xE7\xE3o), SEMPRE pe\xE7a confirma\xE7\xE3o expl\xEDcita do usu\xE1rio
- Para a\xE7\xF5es de NAVEGA\xC7\xC3O (abrir tela), execute direto sem pedir confirma\xE7\xE3o
- Se n\xE3o tiver certeza, sugira escalar para humano
- Responda em portugu\xEAs brasileiro, m\xE1ximo 3 frases (a menos que pe\xE7am detalhes)
- Use os DADOS DA LOJA fornecidos abaixo para responder perguntas reais sobre vendas, estoque e contas

A\xC7\xD5ES QUE MODIFICAM DADOS (precisam de confirma\xE7\xE3o, needs_confirm: true):
- sales-create | stock-adjust | returns-create

A\xC7\xD5ES DE NAVEGA\xC7\xC3O (executam direto, sem needs_confirm):
- navigate: abre uma rota. Use action_payload: { route: "/caminho" }. Rotas v\xE1lidas:
  /vendas/nova | /produtos | /produtos-parados | /estoque | /vendas | /trocas | /financeiro
  /contas-a-receber | /contas-a-pagar | /clientes | /entregas | /relatorios | /relatorios/compras

CONSULTAS REAIS (use action: "query" para buscar dados espec\xEDficos antes de responder).
SEMPRE use uma query quando o usu\xE1rio pedir alertas, hist\xF3rico de produto, dados de cliente, ou recomenda\xE7\xF5es. Cada query retorna automaticamente um link de navega\xE7\xE3o para a tela correspondente.

- target: "notifications" \u2014 alertas ativos. payload: { target: "notifications", limit?: 10 } \u2192 link /notificacoes (ou /dashboard)
- target: "product_history" \u2014 hist\xF3rico do produto. Use product_id (uuid) OU product_name (string para busca). payload: { target: "product_history", product_id?: "uuid", product_name?: "tela iphone" } \u2192 link /produtos
- target: "customer_360" \u2014 vis\xE3o 360. Use customer_id OU customer_name. payload: { target: "customer_360", customer_id?: "uuid", customer_name?: "jo\xE3o" } \u2192 link /clientes
- target: "dashboard_intelligence" \u2014 top recomenda\xE7\xF5es. payload: { target: "dashboard_intelligence", limit?: 5 } \u2192 link /dashboard

Sempre que o usu\xE1rio mencionar um nome de produto/cliente sem ID, use product_name/customer_name \u2014 a fun\xE7\xE3o resolve sozinha.

A\xC7\xD5ES DE LEITURA:
- reports-summary: gerar relat\xF3rio (aceita from, to)

Formato de resposta (sempre JSON puro):
- Sem a\xE7\xE3o: {"reply": "..."}
- Navega\xE7\xE3o: {"reply": "Abrindo X...", "action": "navigate", "action_payload": {"route": "/..."}}
- Consulta de dados: {"reply": "Vou consultar...", "action": "query", "action_payload": {"target": "notifications"}}
- A\xE7\xE3o destrutiva: {"reply": "...", "action": "...", "action_payload": {...}, "needs_confirm": true}
- Escalar: {"reply": "...", "handoff": true, "handoff_reason": "..."}

CONTEXTO DO USU\xC1RIO:
- Rota atual: {{route}}
- Role: {{role}}
- Loja: {{store_id}}

DADOS DA LOJA (snapshot agora):
{{live_data}}`;
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "missing_token" }, 401);
    const userClient = (0, import_supabase_js_2_49.createClient)(SB_URL, SB_ANON, {
      global: { headers: { Authorization: authHeader } }
    });
    const { data: { user }, error: authErr } = await userClient.auth.getUser();
    if (authErr || !user) return json({ error: "unauthorized" }, 401);
    const { data: profile } = await userClient.rpc("current_profile");
    if (!profile?.[0]) return json({ error: "profile_not_found" }, 403);
    const ctx = profile[0];
    const body = await req.json();
    const { message, route, conversation_id, confirm_action, stream } = body;
    if (!message?.trim() && !confirm_action) {
      return json({ error: "message_required" }, 400);
    }
    const svc = (0, import_supabase_js_2_49.createClient)(SB_URL, SB_SERVICE);
    if (confirm_action && conversation_id) {
      return await handleConfirmation(svc, userClient, authHeader, ctx, conversation_id, confirm_action);
    }
    let convId = conversation_id;
    if (!convId) {
      const { data: conv, error: convErr } = await userClient.from("ai_conversations").insert({ store_id: ctx.store_id, profile_id: ctx.profile_id, route, status: "active" }).select("id").single();
      if (convErr) throw convErr;
      convId = conv.id;
    }
    const redacted = redactSensitive(message);
    await svc.from("ai_messages").insert({
      conversation_id: convId,
      role: "user",
      content: message,
      redacted_content: redacted !== message ? redacted : null
    });
    const { data: history } = await svc.from("ai_messages").select("role, content").eq("conversation_id", convId).order("created_at", { ascending: true }).limit(10);
    const { data: training } = await svc.from("ai_training_data").select("intent, category, question_example, answer_template, action_type").or(`is_global.eq.true,store_id.eq.${ctx.store_id}`).limit(30);
    const trainingContext = training?.map(
      (t) => `Intent: ${t.intent} | Cat: ${t.category} | Ex: "${t.question_example}" | Resp: "${t.answer_template}" | A\xE7\xE3o: ${t.action_type || "nenhuma"}`
    ).join("\n") || "";
    const liveData = await loadLiveStoreData(svc, ctx.store_id);
    const systemPrompt = SYSTEM_PROMPT.replace("{{route}}", route || "/").replace("{{role}}", ctx.role).replace("{{store_id}}", ctx.store_id).replace("{{live_data}}", liveData) + `

BASE DE CONHECIMENTO:
${trainingContext}`;
    const messages = [
      { role: "system", content: systemPrompt },
      ...(history || []).map((m) => ({
        role: m.role === "user" ? "user" : "assistant",
        content: m.content
      }))
    ];
    const aiResp = await fetch(AI_GATEWAY, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages,
        temperature: 0.2,
        max_tokens: 600,
        stream: !!stream
      })
    });
    if (!aiResp.ok) {
      const status = aiResp.status;
      if (status === 429) return json({ error: "rate_limited", reply: "Muitas requisi\xE7\xF5es. Tente novamente em alguns segundos." }, 429);
      if (status === 402) return json({ error: "credits_exhausted", reply: "Cr\xE9ditos de IA esgotados. Contate o administrador." }, 402);
      console.error("AI error:", status, await aiResp.text());
      return json({ error: "ai_error", reply: "Erro ao consultar o assistente. Tente novamente." }, 500);
    }
    if (stream && aiResp.body) {
      const reader = aiResp.body.getReader();
      const encoder = new TextEncoder();
      const decoder = new TextDecoder();
      let fullContent = "";
      const readable = new ReadableStream({
        async start(controller) {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ conversation_id: convId })}

`));
          let buffer = "";
          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              buffer += decoder.decode(value, { stream: true });
              let nlIdx;
              while ((nlIdx = buffer.indexOf("\n")) !== -1) {
                let line = buffer.slice(0, nlIdx);
                buffer = buffer.slice(nlIdx + 1);
                if (line.endsWith("\r")) line = line.slice(0, -1);
                if (!line.startsWith("data: ")) continue;
                const payload = line.slice(6).trim();
                if (payload === "[DONE]") {
                  controller.enqueue(encoder.encode("data: [DONE]\n\n"));
                  continue;
                }
                try {
                  const parsed = JSON.parse(payload);
                  const delta = parsed.choices?.[0]?.delta?.content;
                  if (delta) {
                    fullContent += delta;
                    controller.enqueue(encoder.encode(`data: ${JSON.stringify({ delta })}

`));
                  }
                } catch {
                }
              }
            }
          } catch (e) {
            console.error("Stream read error:", e);
          }
          try {
            const redactedReply2 = redactSensitive(fullContent);
            await svc.from("ai_messages").insert({
              conversation_id: convId,
              role: "assistant",
              content: fullContent,
              redacted_content: redactedReply2 !== fullContent ? redactedReply2 : null
            });
            const jsonMatch = fullContent.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
              try {
                const parsed = JSON.parse(jsonMatch[0]);
                if (parsed.action && parsed.needs_confirm) {
                  const { data: evt } = await svc.from("ai_events").insert({
                    conversation_id: convId,
                    store_id: ctx.store_id,
                    action_type: parsed.action,
                    action_payload: parsed.action_payload || null,
                    confirmed: false
                  }).select("id").single();
                  controller.enqueue(encoder.encode(`data: ${JSON.stringify({
                    action: parsed.action,
                    event_id: evt?.id,
                    needs_confirm: true,
                    action_payload: parsed.action_payload
                  })}

`));
                }
                if (parsed.handoff) {
                  await svc.from("ai_handoffs").insert({
                    conversation_id: convId,
                    store_id: ctx.store_id,
                    reason: parsed.handoff_reason || "Solicitado pelo assistente",
                    status: "pending"
                  });
                  controller.enqueue(encoder.encode(`data: ${JSON.stringify({ handoff: true })}

`));
                }
                if (parsed.action === "query" && parsed.action_payload) {
                  const qResult = await runQueryTool(userClient, parsed.action_payload);
                  const summary = summarizeQueryResult(parsed.action_payload.target, qResult);
                  await svc.from("ai_messages").insert({
                    conversation_id: convId,
                    role: "assistant",
                    content: summary.text
                  });
                  await svc.from("ai_events").insert({
                    conversation_id: convId,
                    store_id: ctx.store_id,
                    action_type: "query",
                    action_payload: parsed.action_payload,
                    confirmed: true,
                    result: { data: qResult, nav_link: summary.link }
                  });
                  controller.enqueue(encoder.encode(`data: ${JSON.stringify({
                    query_summary: summary.text,
                    nav_link: summary.link
                  })}

`));
                }
              } catch {
              }
            }
          } catch (e) {
            console.error("Post-stream save error:", e);
          }
          controller.close();
        }
      });
      return new Response(readable, {
        headers: { ...corsHeaders, "Content-Type": "text/event-stream", "Cache-Control": "no-cache" }
      });
    }
    const aiData = await aiResp.json();
    const rawContent = aiData.choices?.[0]?.message?.content || "";
    let reply = rawContent;
    let action = null;
    let actionPayload = null;
    let needsConfirm = false;
    let handoff = false;
    let handoffReason = "";
    try {
      const jsonMatch = rawContent.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        reply = parsed.reply || rawContent;
        action = parsed.action || null;
        actionPayload = parsed.action_payload || null;
        needsConfirm = parsed.needs_confirm || false;
        handoff = parsed.handoff || false;
        handoffReason = parsed.handoff_reason || "";
      }
    } catch {
    }
    const redactedReply = redactSensitive(reply);
    await svc.from("ai_messages").insert({
      conversation_id: convId,
      role: "assistant",
      content: reply,
      redacted_content: redactedReply !== reply ? redactedReply : null
    });
    let eventId = null;
    if (action && needsConfirm) {
      const { data: evt } = await svc.from("ai_events").insert({
        conversation_id: convId,
        store_id: ctx.store_id,
        action_type: action,
        action_payload: actionPayload,
        confirmed: false
      }).select("id").single();
      eventId = evt?.id || null;
    }
    if (handoff) {
      await svc.from("ai_handoffs").insert({
        conversation_id: convId,
        store_id: ctx.store_id,
        reason: handoffReason || "Solicitado pelo assistente",
        status: "pending"
      });
    }
    let queryResult = void 0;
    let navLink = void 0;
    if (action === "query" && actionPayload) {
      queryResult = await runQueryTool(userClient, actionPayload);
      const summary = summarizeQueryResult(actionPayload.target, queryResult);
      reply = `${reply}

${summary.text}`.trim();
      navLink = summary.link;
      await svc.from("ai_messages").insert({
        conversation_id: convId,
        role: "assistant",
        content: summary.text
      });
      await svc.from("ai_events").insert({
        conversation_id: convId,
        store_id: ctx.store_id,
        action_type: "query",
        action_payload: actionPayload,
        confirmed: true,
        result: { data: queryResult, nav_link: navLink }
      });
      action = null;
      actionPayload = null;
    }
    return json({
      conversation_id: convId,
      reply,
      action: action || void 0,
      action_payload: actionPayload || void 0,
      needs_confirm: needsConfirm || void 0,
      event_id: eventId || void 0,
      handoff: handoff || void 0,
      query_result: queryResult,
      nav_link: navLink
    }, 200);
  } catch (e) {
    console.error("ai-support-chat error:", e);
    return json({ error: "internal_error", reply: "Erro interno. Tente novamente." }, 500);
  }
});
async function handleConfirmation(svc, userClient, authHeader, ctx, conversationId, confirmAction) {
  const { event_id, confirmed } = confirmAction;
  const { data: evt, error: evtErr } = await svc.from("ai_events").select("*").eq("id", event_id).eq("store_id", ctx.store_id).single();
  if (evtErr || !evt) return json({ error: "event_not_found" }, 404);
  if (evt.confirmed) return json({ error: "already_processed", reply: "Esta a\xE7\xE3o j\xE1 foi processada." }, 409);
  if (!confirmed) {
    await svc.from("ai_events").update({ confirmed: false, result: { cancelled: true } }).eq("id", event_id);
    const reply = "A\xE7\xE3o cancelada. Como posso ajudar?";
    await svc.from("ai_messages").insert({ conversation_id: conversationId, role: "assistant", content: reply });
    return json({ conversation_id: conversationId, reply }, 200);
  }
  const actionType = evt.action_type;
  const payload = evt.action_payload || {};
  const idemKey = crypto.randomUUID();
  let functionName;
  let functionBody;
  switch (actionType) {
    case "sales-create":
      functionName = "sales-create";
      functionBody = { store_id: ctx.store_id, ...payload };
      break;
    case "stock-adjust":
      functionName = "stock-adjust";
      functionBody = { store_id: ctx.store_id, ...payload };
      break;
    case "returns-create":
      functionName = "returns-create";
      functionBody = { store_id: ctx.store_id, ...payload };
      break;
    case "reports-summary":
      functionName = "reports-summary";
      functionBody = { store_id: ctx.store_id, ...payload };
      break;
    default:
      return json({ error: "unknown_action", reply: "A\xE7\xE3o desconhecida." }, 400);
  }
  try {
    const fnUrl = `${SB_URL}/functions/v1/${functionName}`;
    const method = actionType === "reports-summary" ? "GET" : "POST";
    const fetchOpts = {
      method,
      headers: {
        Authorization: authHeader,
        "Content-Type": "application/json",
        ...actionType !== "reports-summary" ? { "Idempotency-Key": idemKey } : {}
      }
    };
    if (method === "POST") {
      fetchOpts.body = JSON.stringify(functionBody);
    }
    const result = await fetch(
      method === "GET" ? `${fnUrl}?${new URLSearchParams(functionBody)}` : fnUrl,
      fetchOpts
    );
    const resultData = await result.json();
    await svc.from("ai_events").update({
      confirmed: true,
      result: { status: result.status, data: resultData }
    }).eq("id", event_id);
    const successReply = result.ok ? `\u2705 A\xE7\xE3o executada com sucesso! ${JSON.stringify(resultData)}` : `\u274C Erro ao executar: ${resultData.error || resultData.message || "Erro desconhecido"}`;
    await svc.from("ai_messages").insert({
      conversation_id: conversationId,
      role: "assistant",
      content: successReply
    });
    return json({
      conversation_id: conversationId,
      reply: successReply,
      action_result: resultData,
      action_success: result.ok
    }, 200);
  } catch (e) {
    console.error("Action execution error:", e);
    const errReply = "\u274C Erro ao executar a a\xE7\xE3o. Tente novamente.";
    await svc.from("ai_messages").insert({ conversation_id: conversationId, role: "assistant", content: errReply });
    return json({ conversation_id: conversationId, reply: errReply }, 500);
  }
}
async function loadLiveStoreData(svc, storeId) {
  try {
    const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    const monthStart = /* @__PURE__ */ new Date();
    monthStart.setUTCDate(1);
    monthStart.setUTCHours(0, 0, 0, 0);
    const weekStart = /* @__PURE__ */ new Date();
    weekStart.setUTCDate(weekStart.getUTCDate() - 7);
    const [todaySalesRes, monthSalesRes, weekSalesRes, lowStockRes, receivableRes, payableRes, topProdRes] = await Promise.all([
      svc.from("sales").select("net_total").eq("store_id", storeId).eq("status", "paid").is("deleted_at", null).gte("created_at", today),
      svc.from("sales").select("net_total, profit_gross").eq("store_id", storeId).eq("status", "paid").is("deleted_at", null).gte("created_at", monthStart.toISOString()),
      svc.from("sales").select("net_total").eq("store_id", storeId).eq("status", "paid").is("deleted_at", null).gte("created_at", weekStart.toISOString()),
      svc.from("products").select("name, on_hand, minimum_stock").eq("store_id", storeId).eq("is_active", true),
      svc.from("sales").select("amount_pending, due_date").eq("store_id", storeId).is("deleted_at", null).in("payment_status", ["pending", "partial"]),
      svc.from("accounts_payable").select("amount, due_date, description").eq("store_id", storeId).eq("status", "pending"),
      svc.from("sale_items").select("qty, line_total, products!inner(name, store_id)").eq("products.store_id", storeId).limit(500)
    ]);
    const todayCount = todaySalesRes.data?.length || 0;
    const todayRev = (todaySalesRes.data || []).reduce((s, r) => s + Number(r.net_total || 0), 0);
    const monthRev = (monthSalesRes.data || []).reduce((s, r) => s + Number(r.net_total || 0), 0);
    const monthProfit = (monthSalesRes.data || []).reduce((s, r) => s + Number(r.profit_gross || 0), 0);
    const weekRev = (weekSalesRes.data || []).reduce((s, r) => s + Number(r.net_total || 0), 0);
    const lowStock = (lowStockRes.data || []).filter((p) => p.on_hand <= p.minimum_stock);
    const lowStockTop = lowStock.slice(0, 5).map((p) => `${p.name} (${p.on_hand}/${p.minimum_stock})`).join(", ");
    const receivablePending = (receivableRes.data || []).reduce((s, r) => s + Number(r.amount_pending || 0), 0);
    const receivableOverdue = (receivableRes.data || []).filter((r) => r.due_date && r.due_date < today).reduce((s, r) => s + Number(r.amount_pending || 0), 0);
    const payablePending = (payableRes.data || []).reduce((s, r) => s + Number(r.amount || 0), 0);
    const payableOverdue = (payableRes.data || []).filter((r) => r.due_date < today);
    const payableOverdueAmt = payableOverdue.reduce((s, r) => s + Number(r.amount || 0), 0);
    const payableOverdueList = payableOverdue.slice(0, 3).map((r) => `${r.description} (${r.due_date})`).join("; ");
    const aggMap = /* @__PURE__ */ new Map();
    for (const it of topProdRes.data || []) {
      const name = it.products?.name || "?";
      aggMap.set(name, (aggMap.get(name) || 0) + Number(it.line_total || 0));
    }
    const top3 = [...aggMap.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([n, v]) => `${n} (R$ ${v.toFixed(2)})`).join(", ");
    const f = (n) => `R$ ${n.toFixed(2)}`;
    return [
      `Vendas hoje: ${todayCount} venda(s), faturamento ${f(todayRev)}`,
      `Vendas 7 dias: ${f(weekRev)}`,
      `M\xEAs atual: receita ${f(monthRev)}, lucro ${f(monthProfit)}`,
      `Estoque baixo: ${lowStock.length} produto(s)${lowStockTop ? ` \u2014 top: ${lowStockTop}` : ""}`,
      `A receber: ${f(receivablePending)} (vencido: ${f(receivableOverdue)})`,
      `A pagar pendente: ${f(payablePending)}; vencidas: ${payableOverdue.length} (${f(payableOverdueAmt)})${payableOverdueList ? ` \u2014 ${payableOverdueList}` : ""}`,
      `Top produtos por receita: ${top3 || "\u2014"}`
    ].join("\n");
  } catch (e) {
    console.error("loadLiveStoreData error:", e);
    return "(dados indispon\xEDveis no momento)";
  }
}
async function runQueryTool(client, payload) {
  const target = String(payload.target || "");
  try {
    if (target === "notifications") {
      const limit = Number(payload.limit ?? 10);
      const { data, error } = await client.from("notifications").select("id, type, severity, title, description, link, created_at, read_at").is("read_at", null).order("created_at", { ascending: false }).limit(limit);
      if (error) throw error;
      return data;
    }
    if (target === "product_history") {
      let productId = String(payload.product_id || "");
      let productName = String(payload.product_name || "").slice(0, 100);
      if (!productId && productName) {
        const safe = productName.replace(/[,().*%\\]/g, "").trim();
        if (safe) {
          const { data: matches } = await client.from("products").select("id, name").or(`name.ilike.%${safe}%,sku.ilike.%${safe}%`).limit(1);
          if (matches?.[0]) {
            productId = matches[0].id;
            productName = matches[0].name;
          }
        }
      }
      if (!productId) return { error: "produto_nao_encontrado" };
      const { data, error } = await client.rpc("product_history", { p_product_id: productId });
      if (error) throw error;
      return { product_id: productId, product_name: productName, history: (data || []).slice(0, 20) };
    }
    if (target === "customer_360") {
      let customerId = String(payload.customer_id || "");
      const customerName = String(payload.customer_name || "").slice(0, 100);
      if (!customerId && customerName) {
        const safe = customerName.replace(/[,().*%\\]/g, "").trim();
        if (safe) {
          const { data: matches } = await client.from("customers").select("id, name").or(`name.ilike.%${safe}%,phone.ilike.%${safe}%,email.ilike.%${safe}%`).limit(1);
          if (matches?.[0]) customerId = matches[0].id;
        }
      }
      if (!customerId) return { error: "cliente_nao_encontrado" };
      const { data, error } = await client.rpc("customer_360", { p_customer_id: customerId });
      if (error) throw error;
      return data;
    }
    if (target === "dashboard_intelligence") {
      const limit = Number(payload.limit ?? 5);
      const { data, error } = await client.rpc("dashboard_intelligence", { p_limit: limit });
      if (error) throw error;
      return data;
    }
    return { error: "unknown_target" };
  } catch (e) {
    console.error("runQueryTool error:", e);
    return { error: String(e.message || e) };
  }
}
function summarizeQueryResult(target, result) {
  if (!result) return { text: "N\xE3o encontrei resultados." };
  const r = result;
  if (r.error) return { text: `\u26A0\uFE0F N\xE3o foi poss\xEDvel consultar: ${r.error}` };
  if (target === "notifications") {
    if (!Array.isArray(r) || r.length === 0) return { text: "\u{1F389} Nenhuma notifica\xE7\xE3o ativa.", link: { route: "/dashboard", label: "Ir ao dashboard" } };
    const lines = r.slice(0, 5).map(
      (n) => `\u2022 [${n.severity}] ${n.title}${n.description ? ` \u2014 ${n.description}` : ""}`
    );
    const firstLink = r.find((n) => n.link)?.link || "/dashboard";
    return { text: `\u{1F4EC} ${r.length} alerta(s):
${lines.join("\n")}`, link: { route: firstLink, label: "Abrir alertas" } };
  }
  if (target === "product_history") {
    const hist = r.history || [];
    if (!Array.isArray(hist) || hist.length === 0) {
      return { text: `Sem hist\xF3rico para ${r.product_name || "esse produto"}.`, link: { route: "/produtos", label: "Ver produtos" } };
    }
    const lines = hist.slice(0, 8).map((h) => {
      const dt = new Date(h.occurred_at).toLocaleString("pt-BR");
      const who = h.actor_name || "sistema";
      return `\u2022 ${dt} \u2014 ${h.event_type}${h.qty ? ` (${h.qty})` : ""} por ${who}`;
    });
    return {
      text: `\u{1F4DC} Hist\xF3rico de ${r.product_name || "produto"} (${hist.length} eventos):
${lines.join("\n")}`,
      link: { route: "/produtos", label: "Abrir produto" }
    };
  }
  if (target === "customer_360") {
    const t = r.totals || {};
    const cid = r.customer?.id;
    return {
      text: `\u{1F464} ${r.customer?.name || "Cliente"}: ${t.sales_count || 0} compra(s), gasto total R$ ${Number(t.total_spent || 0).toFixed(2)}, pendente R$ ${Number(t.total_pending || 0).toFixed(2)}, ticket m\xE9dio R$ ${Number(t.avg_ticket || 0).toFixed(2)}.`,
      link: cid ? { route: `/clientes?focus=${cid}`, label: "Abrir ficha do cliente" } : { route: "/clientes", label: "Ver clientes" }
    };
  }
  if (target === "dashboard_intelligence") {
    if (!Array.isArray(r) || r.length === 0) return { text: "\u{1F389} Tudo em ordem.", link: { route: "/dashboard", label: "Ver dashboard" } };
    const lines = r.slice(0, 5).map((x) => `\u2022 [${x.severity}] ${x.title} \u2014 ${x.description}`);
    const firstLink = r.find((x) => x.link)?.link || "/dashboard";
    return { text: `\u{1F9E0} Top recomenda\xE7\xF5es:
${lines.join("\n")}`, link: { route: firstLink, label: "Abrir recomenda\xE7\xE3o" } };
  }
  return { text: "Consulta executada." };
}
