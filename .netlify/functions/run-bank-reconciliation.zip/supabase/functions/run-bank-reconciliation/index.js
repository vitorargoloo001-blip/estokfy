// supabase/functions/run-bank-reconciliation/index.ts
var import_server = require("https://deno.land/std@0.208.0/http/server.ts");
var import_supabase_js_2 = require("https://esm.sh/@supabase/supabase-js@2");
var supabase = (0, import_supabase_js_2.createClient)(
  Deno.env.get("SUPABASE_URL") || "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || ""
);
(0, import_server.serve)(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
      }
    });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  }
  try {
    const payload = await req.json();
    const { store_id, bank_connection_id, user_id } = payload;
    if (!store_id) {
      return new Response(
        JSON.stringify({ error: "Missing store_id" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }
    const { data: transactions, error: txError } = await supabase.from("bank_transactions").select("id, amount, transaction_date, description").eq("store_id", store_id).eq("status", "pending").gt("transaction_date", new Date(Date.now() - 90 * 24 * 60 * 60 * 1e3).toISOString());
    if (txError) {
      console.error("Error fetching transactions:", txError);
      return new Response(
        JSON.stringify({ error: "Failed to fetch transactions" }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }
    const { data: sales, error: salesError } = await supabase.from("sales").select("id, total_amount, sale_date, customer_id").eq("store_id", store_id).eq("status", "completed").gt("sale_date", new Date(Date.now() - 90 * 24 * 60 * 60 * 1e3).toISOString());
    if (salesError) {
      console.error("Error fetching sales:", salesError);
      return new Response(
        JSON.stringify({ error: "Failed to fetch sales" }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }
    const { data: customers } = await supabase.from("customers").select("id, name");
    const customerMap = new Map(customers?.map((c) => [c.id, c.name]) || []);
    const matches = [];
    for (const tx of transactions || []) {
      let bestMatch = tryDeterministicMatch(tx, sales || []);
      if (!bestMatch) {
        bestMatch = tryHeuristicMatch(tx, sales || [], customerMap);
      }
      if (!bestMatch) {
        bestMatch = tryFuzzyMatch(tx, sales || []);
      }
      if (bestMatch) {
        matches.push(bestMatch);
      } else {
        matches.push({
          transaction_id: tx.id,
          sale_id: null,
          confidence_score: 0,
          match_type: "unmatched",
          amount_difference: null,
          date_difference_days: null
        });
      }
    }
    let autoReconciled = 0;
    let pendingReview = 0;
    for (const match of matches) {
      if (match.confidence_score >= 90 && match.sale_id) {
        await supabase.from("reconciliation_matches").insert({
          bank_transaction_id: match.transaction_id,
          suggested_sale_id: match.sale_id,
          confidence_score: match.confidence_score,
          match_type: match.match_type,
          amount_difference: match.amount_difference,
          date_difference_days: match.date_difference_days,
          status: "confirmed"
        });
        await supabase.from("bank_transactions").update({ status: "reconciled" }).eq("id", match.transaction_id);
        autoReconciled++;
      } else if (match.confidence_score >= 60 && match.sale_id) {
        await supabase.from("reconciliation_matches").insert({
          bank_transaction_id: match.transaction_id,
          suggested_sale_id: match.sale_id,
          confidence_score: match.confidence_score,
          match_type: match.match_type,
          amount_difference: match.amount_difference,
          date_difference_days: match.date_difference_days,
          status: "pending"
        });
        await supabase.from("bank_transactions").update({ status: "pending" }).eq("id", match.transaction_id);
        pendingReview++;
      } else {
        await supabase.from("reconciliation_matches").insert({
          bank_transaction_id: match.transaction_id,
          suggested_sale_id: null,
          confidence_score: match.confidence_score,
          match_type: "unmatched",
          status: "unmatched"
        });
        await supabase.from("bank_transactions").update({ status: "pending" }).eq("id", match.transaction_id);
      }
    }
    if (user_id) {
      await supabase.rpc("log_connect_audit", {
        p_store_id: store_id,
        p_user_id: user_id,
        p_action: `Reconcilia\xE7\xE3o executada: ${autoReconciled} auto-conciliadas, ${pendingReview} para revis\xE3o`,
        p_action_type: "reconciliation",
        p_entity_type: "reconciliation",
        p_details: {
          auto_reconciled: autoReconciled,
          pending_review: pendingReview,
          total_matches: matches.length
        }
      });
    }
    return new Response(
      JSON.stringify({
        success: true,
        auto_reconciled: autoReconciled,
        pending_review: pendingReview,
        total_processed: matches.length,
        message: `Reconcilia\xE7\xE3o conclu\xEDda: ${autoReconciled} conciliadas, ${pendingReview} para revis\xE3o, ${matches.length - autoReconciled - pendingReview} n\xE3o identificadas`
      }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in run-bank-reconciliation:", error);
    return new Response(
      JSON.stringify({ error: String(error) }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
});
function tryDeterministicMatch(tx, sales) {
  const txDate = new Date(tx.date).toDateString();
  for (const sale of sales) {
    const saleDate = new Date(sale.sale_date).toDateString();
    if (Math.abs(tx.amount - sale.total_amount) < 0.01 && txDate === saleDate) {
      return {
        transaction_id: tx.id,
        sale_id: sale.id,
        confidence_score: 100,
        match_type: "deterministic",
        amount_difference: 0,
        date_difference_days: 0
      };
    }
  }
  return null;
}
function tryHeuristicMatch(tx, sales, customerMap) {
  let bestMatch = null;
  let bestScore = 60;
  for (const sale of sales) {
    const txDate = new Date(tx.date);
    const saleDate = new Date(sale.sale_date);
    const dateDiff = Math.abs(txDate.getTime() - saleDate.getTime()) / (24 * 60 * 60 * 1e3);
    if (dateDiff > 2) continue;
    const amountDiff = Math.abs(tx.amount - sale.total_amount);
    const percentDiff = amountDiff / sale.total_amount * 100;
    if (percentDiff > 1) continue;
    const customerName = customerMap.get(sale.customer_id) || "";
    const descLower = tx.description.toLowerCase();
    const hasCustomerName = descLower.includes(customerName.toLowerCase());
    let score = 75;
    score += (1 - percentDiff) * 10;
    score += (1 - dateDiff / 2) * 10;
    if (hasCustomerName) score += 5;
    if (score > bestScore) {
      bestScore = score;
      bestMatch = {
        transaction_id: tx.id,
        sale_id: sale.id,
        confidence_score: Math.min(95, Math.round(score)),
        match_type: "heuristic",
        amount_difference: amountDiff,
        date_difference_days: Math.round(dateDiff)
      };
    }
  }
  return bestMatch;
}
function tryFuzzyMatch(tx, sales) {
  let bestMatch = null;
  let bestScore = 50;
  const txDate = new Date(tx.date);
  for (const sale of sales) {
    const saleDate = new Date(sale.sale_date);
    const dateDiff = Math.abs(txDate.getTime() - saleDate.getTime()) / (24 * 60 * 60 * 1e3);
    if (dateDiff > 7) continue;
    const amountDiff = Math.abs(tx.amount - sale.total_amount);
    const percentDiff = amountDiff / sale.total_amount * 100;
    if (percentDiff > 5) continue;
    let score = 60;
    score += (1 - percentDiff / 5) * 5;
    score += (1 - dateDiff / 7) * 5;
    if (score > bestScore) {
      bestScore = score;
      bestMatch = {
        transaction_id: tx.id,
        sale_id: sale.id,
        confidence_score: Math.round(score),
        match_type: "fuzzy",
        amount_difference: amountDiff,
        date_difference_days: Math.round(dateDiff)
      };
    }
  }
  return bestMatch;
}
