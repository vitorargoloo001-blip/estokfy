// supabase/functions/connect-webhook/index.ts
var import_supabase_js_2_49 = require("https://esm.sh/@supabase/supabase-js@2.49.1");
var import_server = require("https://deno.land/std@0.168.0/http/server.ts");
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function jsonRes(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" }
  });
}
(0, import_server.serve)(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }
  try {
    if (req.method !== "POST") {
      return jsonRes({ error: "method_not_allowed" }, 405);
    }
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const svc = (0, import_supabase_js_2_49.createClient)(supabaseUrl, serviceKey);
    const bodyText = await req.text();
    let payload;
    try {
      payload = JSON.parse(bodyText);
    } catch (_e) {
      return jsonRes({ error: "invalid_json" }, 400);
    }
    const event = payload.event;
    const data = payload.data;
    const createdAt = payload.createdAt;
    if (!event || !data) {
      return jsonRes({ error: "invalid_payload" }, 400);
    }
    const provider = "pluggy";
    const externalEventId = `${provider}-${event}-${data.id}-${createdAt}`;
    const externalConnectionId = data.clientId;
    const externalAccountId = data.accountId;
    const { data: connection } = await svc.from("bank_connections").select("id,store_id,webhook_secret_ref").eq("provider", provider).eq("external_connection_id", externalConnectionId).single();
    if (!connection) {
      console.warn(`webhook: connection not found for clientId ${externalConnectionId}`);
      return jsonRes({ error: "connection_not_found" }, 404);
    }
    if (connection.webhook_secret_ref) {
      const signature = req.headers.get("x-pluggy-signature");
      if (!signature) {
        return jsonRes({ error: "missing_signature" }, 401);
      }
    }
    const { data: existingEvent } = await svc.from("webhook_events").select("id,status").eq("provider", provider).eq("external_event_id", externalEventId).single();
    if (existingEvent) {
      return jsonRes({ webhook_event_id: existingEvent.id, duplicate: true }, 200);
    }
    const { data: insertedEvent, error: insertErr } = await svc.from("webhook_events").insert({
      provider,
      external_event_id: externalEventId,
      connection_id: connection.id,
      store_id: connection.store_id,
      event_type: event,
      payload,
      signature_valid: true,
      // TODO: implement actual validation
      status: "received",
      received_at: (/* @__PURE__ */ new Date()).toISOString()
    }).select("id").single();
    if (insertErr) {
      console.error("webhook insert error:", insertErr);
      return jsonRes({ error: "insert_failed", details: insertErr.message }, 500);
    }
    return jsonRes({
      webhook_event_id: insertedEvent.id,
      provider,
      event_type: event,
      store_id: connection.store_id,
      status: "received"
    }, 202);
  } catch (e) {
    console.error("connect-webhook error:", e);
    return jsonRes({ error: "internal_error", details: String(e) }, 500);
  }
});
