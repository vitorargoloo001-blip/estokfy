// supabase/functions/bank-webhook-handler/index.ts
var import_server = require("https://deno.land/std@0.208.0/http/server.ts");
var import_crypto = require("https://deno.land/std@0.208.0/node/crypto.ts");
var import_supabase_js_2 = require("https://esm.sh/@supabase/supabase-js@2");
var supabase = (0, import_supabase_js_2.createClient)(
  Deno.env.get("SUPABASE_URL") || "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || ""
);
var PLUGGY_WEBHOOK_SECRET = Deno.env.get("PLUGGY_WEBHOOK_SECRET") || "";
(0, import_server.serve)(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, X-Pluggy-Signature"
      }
    });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" }
    });
  }
  try {
    const signature = req.headers.get("x-pluggy-signature");
    if (!signature) {
      return new Response(JSON.stringify({ error: "Missing signature" }), {
        status: 401,
        headers: { "Content-Type": "application/json" }
      });
    }
    const body = await req.text();
    const hash = (0, import_crypto.createHmac)("sha256", PLUGGY_WEBHOOK_SECRET);
    hash.update(body);
    const computedSignature = hash.digest("hex");
    if (computedSignature !== signature) {
      console.warn("Invalid webhook signature");
      return new Response(JSON.stringify({ error: "Invalid signature" }), {
        status: 401,
        headers: { "Content-Type": "application/json" }
      });
    }
    const payload = JSON.parse(body);
    const { id, type, data } = payload;
    console.log(`Processing webhook: ${type} (${id})`);
    const { data: bankConnections, error: bcError } = await supabase.from("bank_connections").select("id, store_id").eq("provider_connection_id", data.id);
    if (bcError || !bankConnections || bankConnections.length === 0) {
      console.warn(`Bank connection not found for provider_id: ${data.id}`);
      return new Response(
        JSON.stringify({ success: true, message: "Bank connection not found, ignoring" }),
        { status: 200, headers: { "Content-Type": "application/json" } }
      );
    }
    const bankConnection = bankConnections[0];
    const { id: bankConnectionId, store_id } = bankConnection;
    const { data: webhookRecord, error: webhookError } = await supabase.rpc(
      "store_provider_webhook",
      {
        p_store_id: store_id,
        p_bank_connection_id: bankConnectionId,
        p_provider: "pluggy",
        p_event_type: type,
        p_webhook_id: id,
        p_payload: payload,
        p_signature: signature
      }
    );
    if (webhookError) {
      console.error("Failed to store webhook event:", webhookError);
    }
    let processed = false;
    let processError = null;
    try {
      switch (type) {
        case "transaction.created":
        case "transaction.updated":
          await fetch(`${Deno.env.get("SUPABASE_URL")}/functions/v1/sync-bank-transactions`, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              store_id,
              bank_connection_id: bankConnectionId
            })
          });
          processed = true;
          break;
        case "account.sync.failed":
          await supabase.rpc("update_bank_connection_sync", {
            p_bank_connection_id: bankConnectionId,
            p_sync_status: "failed",
            p_error_message: `Sync failed: ${data.error || "Unknown error"}`
          });
          processed = true;
          break;
        default:
          console.log(`Unhandled webhook type: ${type}`);
          processed = true;
      }
    } catch (error) {
      processError = String(error);
      console.error(`Error processing webhook ${type}:`, error);
    }
    if (webhookRecord && webhookRecord.length > 0) {
      await supabase.rpc("mark_webhook_processed", {
        p_webhook_id: webhookRecord[0].id,
        p_success: processed,
        p_error_message: processError
      });
    }
    return new Response(
      JSON.stringify({
        success: true,
        event_id: id,
        event_type: type,
        processed,
        error: processError
      }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error in bank-webhook-handler:", error);
    return new Response(
      JSON.stringify({ error: String(error) }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
});
